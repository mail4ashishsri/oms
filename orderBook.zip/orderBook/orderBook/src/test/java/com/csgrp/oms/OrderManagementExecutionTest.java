package com.csgrp.oms;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.Spy;

import com.csgrp.oms.common.InvalidInstrumenFormatException;
import com.csgrp.oms.common.InvalidPriceException;
import com.csgrp.oms.common.InvalidQuantityException;

public class OrderManagementExecutionTest {
	
	@Spy
	OrderManagementImpl orderManagement = OrderManagementImpl.getOrderManagementImpl();

	private void initializeBook() throws InvalidInstrumenFormatException, InvalidQuantityException  {
		orderManagement.clearAllBooks();
		initializeOrderBook();
		initializeOrder();
		closeOrderBook();		
	}

	@Test
	public void testOrderExecution() throws InvalidInstrumenFormatException, InvalidQuantityException, InvalidPriceException {
		initializeBook();
		String status = orderManagement.executeBook("ENIN741IN741", 8000, 90.50);
		assertEquals("Execution completed",status);
	}
	
	@Test
	public void testLinearExecution() throws InvalidInstrumenFormatException, InvalidQuantityException, InvalidPriceException {
		initializeBook(); 
		String status = orderManagement.executeBook("ENIN741IN741", 3000, 90.50);
		assertEquals("Execution completed",status);
	}
	
	@Test
	public void testReexecution() throws InvalidInstrumenFormatException, InvalidQuantityException, InvalidPriceException {
		initializeBook();
		orderManagement.executeBook("ENIN741IN741", 1000, 80.50);
		String status = orderManagement.executeBook("ENIN741IN741", 1500, 80.50);
		assertEquals("Execution completed",status);
	}

	private void initializeOrderBook() throws InvalidInstrumenFormatException {
		orderManagement.openOrderBook("ENIN741IN741");
	}

	private void initializeOrder()
			throws InvalidInstrumenFormatException, InvalidQuantityException {
		orderManagement.bookOrder("ENIN741IN741", 1000, 90.75);
		orderManagement.bookOrder("ENIN741IN741", 3000, 70.75);
		orderManagement.bookOrder("ENIN741IN741", 5000, 0.0);
	}
	
	private void closeOrderBook() throws InvalidInstrumenFormatException {
		orderManagement.closeOrderBook("ENIN741IN741");
	}
}
