package com.csgrp.oms;

import static org.junit.Assert.*;

import java.awt.List;
import java.util.LinkedList;

import org.junit.Before;
import org.junit.Test;
import org.mockito.*;

import com.csgrp.oms.common.InvalidInstrumenFormatException;
import com.csgrp.oms.common.InvalidQuantityException;

public class OrderManagementBookActionTest {

	@Spy
	OrderManagementImpl orderManagement = OrderManagementImpl.getOrderManagementImpl();

	@Before
	public void init() throws InvalidInstrumenFormatException, InvalidQuantityException {
		initializeOrderBook(orderManagement);
		initializeOrder(orderManagement);
	}

	@Test
	public void testGetOrderStatistics() throws InvalidInstrumenFormatException, InvalidQuantityException {
		
		LinkedList<String> totalOrders = (LinkedList<String>) orderManagement.getSumOfEachBook();
		assertEquals(totalOrders.size(), 2);
	}

	@Test
	public void testOpenOrderBook() throws InvalidInstrumenFormatException {

		orderManagement.clearAllBooks();
		Boolean status = orderManagement.openOrderBook("ENIN741IN741");
		assertTrue(status);
	}

	@Test
	public void testOpenInvalidOrderBook() throws InvalidInstrumenFormatException {

		orderManagement.clearAllBooks();
		Boolean status = orderManagement.openOrderBook("ENIN741IN751");
		assertFalse(status);
	}

	@Test
	public void testCloseOrderBook() throws InvalidInstrumenFormatException {

		orderManagement.clearAllBooks();
		orderManagement.openOrderBook("ENIN741IN741");
		Boolean status = orderManagement.closeOrderBook("ENIN741IN741");
		assertTrue(status);
	}
	
	@Test
	public void testBookOrderBook() throws InvalidInstrumenFormatException, InvalidQuantityException {

		orderManagement.clearAllBooks();
		orderManagement.openOrderBook("ENIN741IN741");
		Boolean status = orderManagement.bookOrder("ENIN741IN741", 1000, 100.50);
		assertTrue(status);
	}
	
	@Test
	public void testInvalidOrderBook() throws InvalidInstrumenFormatException, InvalidQuantityException {

		orderManagement.clearAllBooks();
		orderManagement.openOrderBook("ENIN741IN741");
		Boolean status = orderManagement.bookOrder("ENIN741IN742", 1000, 100.50);
		assertFalse(status);
	}
	
	@Test
	public void testOrderExecution() throws InvalidInstrumenFormatException, InvalidQuantityException {

		orderManagement.clearAllBooks();
		orderManagement.openOrderBook("ENIN741IN741");
		Boolean status = orderManagement.bookOrder("ENIN741IN742", 1000, 100.50);
		assertFalse(status);
	}


	private void initializeOrderBook(OrderManagementImpl orders) throws InvalidInstrumenFormatException {
		orders.openOrderBook("ENIN741IN741");
		orders.openOrderBook("ENIN741IN742");
	}

	private void initializeOrder(OrderManagementImpl orders)
			throws InvalidInstrumenFormatException, InvalidQuantityException {
		orders.bookOrder("ENIN741IN741", 1000, 90.75);
		orders.bookOrder("ENIN741IN741", 3000, 70.75);
		orders.bookOrder("ENIN741IN741", 5000, 0.0);
		orders.bookOrder("ENIN741IN742", 2000, 80.5);
		orders.bookOrder("ENIN741IN742", 2000, 90.7);
	}

}
