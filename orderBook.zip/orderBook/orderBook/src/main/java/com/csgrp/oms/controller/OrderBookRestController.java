package com.csgrp.oms.controller;

import java.util.HashMap;
import java.util.List;

import javax.websocket.server.PathParam;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.catalina.connector.Response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.csgrp.oms.OrderManagementImpl;


import generated.UserOrder;

@RestController
public class OrderBookRestController {

	private final String OPEN_SUCCESS 				= "Book opened";
	private final String OOPEN_REQUEST_FAILED 		= "Failed to open new book";
	private final String BOOK_CLOSED 				= "Book closed";
	private final String CLOSE_REQUEST_FAILED 		= "Failed to close book";
	private final String ORDER_BOOKED 				= "Order booked";
	private final String ORDER_FAILED 				= "Order failed";
	private final String EXECUTION_SUCCESS			= "Exeucution sucess";
	private final String EXECUTION_FAILED 			= "Execution failed";
	

	private static final Logger logger = LogManager.getLogger(OrderBookRestController.class);

	@RequestMapping(value = "/openbook/{instrumentId}", method = RequestMethod.POST, consumes = "application/json")
	public String openOrderBook(@PathVariable("instrumentId") String instrumentId) throws Exception {

		try {
			logger.info("Book open request");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();

			if (orderManagemet.openOrderBook(instrumentId)) {
				logger.info(OPEN_SUCCESS);
				return OPEN_SUCCESS;
			} else {
				logger.info(OOPEN_REQUEST_FAILED);
				return OOPEN_REQUEST_FAILED;
			}
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw new Exception(OOPEN_REQUEST_FAILED,ex);
		}
	}

	@RequestMapping(value = "/closebook/{instrumentId}", method = RequestMethod.POST, consumes = "application/json")
	public String closeOrderBook(@PathVariable("instrumentId") String instrumentId) throws Exception {

		try {
			logger.info("Book close request");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();

			if (orderManagemet.closeOrderBook(instrumentId)) {
				logger.info(BOOK_CLOSED);
				return BOOK_CLOSED;
			} else {
				return CLOSE_REQUEST_FAILED;
			}
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw new Exception(CLOSE_REQUEST_FAILED,ex);
		}
	}

	@RequestMapping(value = "/bookorder/", method = RequestMethod.POST, consumes = "application/json")
	public String bookOrder(@RequestBody UserOrder order) throws Exception {

		try {
			logger.info("Book order request");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();
			if (orderManagemet.bookOrder(order.getInstrumentId(), order.getQuantity(), order.getPrice())) {
				logger.info(ORDER_BOOKED);
				return ORDER_BOOKED;
			} else {
				logger.info(ORDER_FAILED);
				return ORDER_FAILED;
			}
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw new Exception(ORDER_FAILED,ex);
		}
	}

	@RequestMapping(value = "/execution/", method = RequestMethod.POST, consumes = "application/json")
	public String execution(@RequestBody UserOrder execution) throws Exception {

		try {
			logger.info("Execution request");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();
			return orderManagemet.executeBook(execution.getInstrumentId(), execution.getQuantity(), execution.getPrice());
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw new Exception(EXECUTION_FAILED,ex);
		}
	}

	@RequestMapping(value = "/books/", method = RequestMethod.GET)
	public List<String> getBooks() {

		try {
			logger.info("Get list of books request");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();
			return orderManagemet.getAllBooks();
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw ex;
		}
	}

	@RequestMapping(value = "/sumofbooks/", method = RequestMethod.GET)
	public List<String> getSumOfBooks() {

		try {
			logger.info("Get sum of books request");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();
			return orderManagemet.getSumOfEachBook();
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw ex;
		}
	}
	
	@RequestMapping(value = "/validorders/", method = RequestMethod.GET)
	public List<String> getValidOrders() {

		try {
			logger.info("Get valid orders");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();
			return orderManagemet.getValidDemand();
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw ex;
		}
	}
	
	@RequestMapping(value = "/invalidorders/", method = RequestMethod.GET)
	public List<String> getInvalidOrders() {

		try {
			logger.info("Get invalid orders");
			OrderManagementImpl orderManagemet = OrderManagementImpl.getOrderManagementImpl();
			return orderManagemet.getInvalidDemand();
		} catch (Exception ex) {
			logger.error("Handling of [" + ex.getClass().getName() + "] resulted in Exception",ex);
			throw ex;
		}
	}
}
