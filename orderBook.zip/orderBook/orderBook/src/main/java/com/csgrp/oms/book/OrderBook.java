package com.csgrp.oms.book;

import java.math.BigDecimal;

public class OrderBook {
	
	String instrumentId;
	Boolean isOpen;
	Boolean isExecuted;
	Double executionPrice;
	
	public OrderBook(String instrumentId){
		this.instrumentId = instrumentId;
		this.isOpen = true;
		this.isExecuted = false;
	}
	
	public Double getExecutionPrice() {
		return executionPrice;
	}
	public void setExecutionPrice(Double executionPrice) {
		this.executionPrice = executionPrice;
	}
	public String getInstrumentId() {
		return instrumentId;
	}
	public void setInstrumentId(String instrumentId) {
		this.instrumentId = instrumentId;
	}
	public Boolean getIsOpen() {
		return isOpen;
	}
	public void setIsOpen(Boolean isOpen) {
		this.isOpen = isOpen;
	}
	public Boolean getIsExecuted() {
		return isExecuted;
	}
	public void setIsExecuted(Boolean isExecuted) {
		this.isExecuted = isExecuted;
	}
	
	
}
