package com.csgrp.oms.book;

import java.util.Date;

import com.csgrp.oms.common.OrderType;


/*
 * It is define order object 
 * 
 * @author	Ashish Srivastava
 * @version	1.0
 * @since	1-12-2019
*/

public final class Order {

	//private final String  instrumentId;
	private final Integer orderId;
	private final Integer quantity;
	private final Date entryDate;
	private final OrderType orderType; 
	private final Double limitPrice;
	
	public Order(Integer orderId, Integer quantity, Double price){
		
		//this.instrumentId = instrumentId;
		this.quantity = quantity;
		this.entryDate = new Date();
		this.orderId =orderId; 
		
		if(price == 0){
			orderType = OrderType.MARKET;
			this.limitPrice = 0.0;
		}
		else{
			orderType = OrderType.LIMIT;
			this.limitPrice = price;
		}
	}
	
	/*
	 * public String getInstrumentId() { return instrumentId; }
	 */

	public Integer getOrderId() {
		return orderId;
	}
	
	public Integer getQuantity() {
		return quantity;
	}
	
	public Date getEntryDate() {
		return entryDate;
	}
	
	public OrderType getOrderType() {
		return orderType;
	}

	public Double getLimitPrice() {
		return limitPrice;
	}
}
