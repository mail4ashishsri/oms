package com.csgrp.oms;

import java.awt.print.Book;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import org.slf4j.IMarkerFactory;
import org.slf4j.Marker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.csgrp.oms.book.Order;
import com.csgrp.oms.book.OrderBook;
import com.csgrp.oms.book.OrderExecution;
import com.csgrp.oms.common.InvalidInstrumenFormatException;
import com.csgrp.oms.common.InvalidPriceException;
import com.csgrp.oms.common.InvalidQuantityException;
import com.csgrp.oms.common.OrderType;
import com.csgrp.oms.OrderManagement;

/**
 * 
 * This class is essentially implemented as a wrapper around an OrderManagement
 * interface.
 * 
 * 
 * @author Ashish
 * @version 1.0
 * @since 1-12-2019
 */

public class OrderManagementImpl implements OrderManagement {

	private static OrderManagementImpl instance = new OrderManagementImpl();

	// List of valid instruments, currently it is populating while initializing
	// but it will further extend to populate from persistence layer
	private List<String> validInstruments = new LinkedList<String>();

	public List<String> getValidInstruments() {
		return validInstruments;
	}

	public void setValidInstruments(List<String> validInstruments) {
		this.validInstruments = validInstruments;
	}

	/**
	 * It is default constructor used to initialize valid instruments.
	 */
	private OrderManagementImpl() {
		initializeValidInstruments();
	}

	/**
	 * Initializing valid instruments
	 */
	private void initializeValidInstruments() {
		validInstruments.add("ENIN741IN741");
		validInstruments.add("ENIN741IN742");
		validInstruments.add("ENIN741IN743");
		validInstruments.add("ENIN741IN744");
		validInstruments.add("ENIN741IN745");
		validInstruments.add("ENIN741IN746");
		validInstruments.add("ENIN741IN747");
		validInstruments.add("ENIN741IN748");
		validInstruments.add("ENIN741IN749");
		validInstruments.add("ENIN741IN750");
	}

	/**
	 * It will return the current object
	 */
	public static OrderManagementImpl getOrderManagementImpl() {
		return instance;
	}

	AtomicInteger orderId = new AtomicInteger(0); // Atomic integer to maintain order id
	private final Map<String, OrderBook> orderBooks = new ConcurrentHashMap<String, OrderBook>(); // Collection of order
																									// books
	private final Map<String, LinkedList<Order>> orders = new ConcurrentHashMap<String, LinkedList<Order>>(); // Collection
																												// of
																												// orders
	private final Map<String, HashMap<Integer, OrderExecution>> executions = new ConcurrentHashMap<String, HashMap<Integer, OrderExecution>>();

	private final String INVALID_INSTRUMENT 	= "Invalid book status";
	private final String INVALID_BOOK_STATUS 	= "Book is still open";
	private final String SUCCESS 				= "Execution completed";
	private final String PARTIAL_EXECUTION 		= "Partial execution completed";
	private final String INVALID_DATA 			= "Invalid data ";

	@Override
	public boolean openOrderBook(String instrumentId) throws InvalidInstrumenFormatException {

		validateInstrument(instrumentId); // Validate valid input
		isValidInstrumentId(instrumentId); // Validate valid instrument id

		if (!orderBooks.containsKey(instrumentId)) {
			orderBooks.put(instrumentId, new OrderBook(instrumentId));
			return true;
		}
		return false;
	}

	@Override
	public boolean closeOrderBook(String instrumentId) throws InvalidInstrumenFormatException {

		validateInstrument(instrumentId); // Validate valid input
		isValidInstrumentId(instrumentId); // Validate valid instrument id

		if (orderBooks.size() > 0 && orderBooks.containsKey(instrumentId)) {
			OrderBook orderBook = orderBooks.get(instrumentId);
			orderBook.setIsOpen(false);
			orderBooks.replace(instrumentId, orderBook);
			return true;
		}
		return false;
	}

	@Override
	public boolean bookOrder(String instrumentId, Integer quantity, Double price)
			throws InvalidInstrumenFormatException, InvalidQuantityException {

		validateInstrument(instrumentId); // Validate valid input
		isValidInstrumentId(instrumentId); // Validate valid instrument id
		validateQuantity(quantity); // validate input quantity

		if (orderBooks.containsKey(instrumentId) && orderBooks.get(instrumentId).getIsOpen()) {
			if (orders.containsKey(instrumentId)) {
				LinkedList<Order> order = orders.get(instrumentId);
				order.add(new Order(orderId.incrementAndGet(), quantity, price));
				orders.replace(instrumentId, order);
				return true;
			} else {
				LinkedList<Order> order = new LinkedList<Order>();
				order.add(new Order(orderId.incrementAndGet(), quantity, price));
				orders.put(instrumentId, order);
				return true;
			}
		}
		return false;
	}

	@Override
	public String executeBook(String instrumentId, Integer quantity, Double executionPrice)
			throws InvalidInstrumenFormatException, InvalidQuantityException, InvalidQuantityException,
			InvalidPriceException {

		validateInstrument(instrumentId); // Validate valid input
		isValidInstrumentId(instrumentId); // Validate valid instrument id
		validateQuantity(quantity); // validate input quantity
		validatePrice(executionPrice); // validate input quantity

		if (!orderBooks.containsKey(instrumentId)) {
			return INVALID_INSTRUMENT;
		} else if (orderBooks.get(instrumentId).getIsOpen() || orderBooks.get(instrumentId).getIsExecuted()) {
			return INVALID_BOOK_STATUS;
		} else {

			Integer validOrderQuantity = getValidQuantity(instrumentId, executionPrice); // get valid order quantity
			Double executionRatio = getExecutionRation(quantity, validOrderQuantity);  // get execution ratio

			if (orderBooks.get(instrumentId).getExecutionPrice() == null || orderBooks.get(instrumentId).getExecutionPrice() == 0) {
				ExecuteOrderBook(instrumentId, quantity, executionRatio, executionPrice); // Execute order book
				if (validOrderQuantity <= quantity) { // Set book execution is true in case valid order quantity is less than available quantity
					orderBooks.get(instrumentId).setIsExecuted(Boolean.TRUE);
				}
			} else if (orderBooks.get(instrumentId).getExecutionPrice().equals(executionPrice)) {
				ReexecuteOrderBook(instrumentId, quantity, executionRatio, executionPrice);
			} else {
				return INVALID_DATA;
			}
		}
		return SUCCESS;
	}

	private Double getExecutionRation(Integer quantity, Integer validOrderQuantity) {

		return (quantity < validOrderQuantity) ? (double) quantity / validOrderQuantity : 1.0;
	}

	/**
	 * Method will be called in case of re-execution only
	 */
	private void ReexecuteOrderBook(String instrumentId, Integer quantity, Double executionRatio,
			Double executionPrice) {

		Map<Integer, OrderExecution> orderExecutions = executions.get(instrumentId);
		LinkedList<Order> orderBook = orders.get(instrumentId);
		Integer allocatedQuatity = 0;

		for (Order order : orderBook) {

			OrderExecution execution = orderExecutions.get(order.getOrderId());
			execution.setExecutionTime(new Date());

			if (!execution.getInvalid()) {
				if (executionRatio >= 1.0) {
					// If quantify execution ration is more than 1 then allocate remaining order quantity
					allocatedQuatity += order.getQuantity() - execution.getAllocation();
					execution.setAllocation(order.getQuantity());
				} else {
					// If quantify execution ration is less than 1 then allocate partially
					if ((int) Math.round(order.getQuantity() * executionRatio) + execution.getAllocation() >= order.getQuantity()) {
						allocatedQuatity += order.getQuantity() - execution.getAllocation();
						execution.setAllocation(order.getQuantity());
					} else {
						allocatedQuatity += (int) Math.round(order.getQuantity() * executionRatio);
						execution.setAllocation(execution.getAllocation() + (int) Math.round(order.getQuantity() * executionRatio));
					}
				}
			}
			orderExecutions.replace(order.getOrderId(), execution);
		}
		executions.replace(instrumentId, (HashMap<Integer, OrderExecution>) orderExecutions);
	}

	/**
	 * Method will be called initial execution only
	 */
	private void ExecuteOrderBook(String instrumentId, Integer quantity, Double executionRatio, Double executionPrice) {

		Map<Integer, OrderExecution> orderExecutions = new HashMap<Integer, OrderExecution>();
		LinkedList<Order> orderBook = orders.get(instrumentId);
		Integer allocatedQuatity = 0;

		orderBooks.get(instrumentId).setExecutionPrice(executionPrice); //Setting book execution price 
		
		for (Order order : orderBook) {

			OrderExecution execution = new OrderExecution();
			execution.setOrderId(order.getOrderId());
			execution.setExecutionTime(new Date());

			if (order.getOrderType() == OrderType.LIMIT && order.getLimitPrice() < executionPrice) {
				execution.setInvalid(Boolean.TRUE);

			} else {
				execution.setInvalid(Boolean.FALSE);
				if (executionRatio >= 1.0) {
					// If quantify execution ration is more than 1 then allocation will be 100%
					execution.setAllocation(order.getQuantity());
					allocatedQuatity += order.getQuantity();

				} else {
					// If execution ration is less than 1 then allocation will be linear
					Integer quantityAllocated = (int) Math.round(order.getQuantity() * executionRatio);
					execution.setAllocation(quantityAllocated);
					allocatedQuatity += quantityAllocated;
				}
			}
			orderExecutions.put(order.getOrderId(), execution);
		}
		executions.put(instrumentId, (HashMap<Integer, OrderExecution>) orderExecutions);
	}

	private Integer getValidQuantity(String instrumentId, Double executionPrice) {

		LinkedList<Order> orderBook = orders.get(instrumentId);
		Integer validOrders = orderBook.stream()
				.filter(e1 -> (e1.getLimitPrice() >= executionPrice || e1.getOrderType() == OrderType.MARKET))
				.mapToInt(e1 -> e1.getQuantity()).sum();

		return validOrders;
	}

	@Override
	public List<String> getSumOfEachBook() {

		List<String> orderSummary = new LinkedList<String>();

		for (Map.Entry<String, OrderBook> book : orderBooks.entrySet()) {
			LinkedList<Order> orderBook = orders.get(book.getKey());
			Integer sumOfOrders = orderBook.stream().mapToInt(e1 -> e1.getQuantity()).sum();
			orderSummary.add(book.getKey() + " | " + sumOfOrders.toString());
		}

		return orderSummary;
	}

	@Override
	public void clearAllBooks() {
		orderBooks.clear();
		orders.clear();
		executions.clear();
	}

	@Override
	public List<String> getOrderStatistics() {

		List<String> orderStatistics = new LinkedList<String>();

		for (Map.Entry<String, OrderBook> book : orderBooks.entrySet()) {

			orderStatistics.add(book.getValue().toString());
			LinkedList<Order> orderBook = orders.get(book.getKey());
			Map<Integer, OrderExecution> orderExecutions = executions.get(book.getKey());
			Iterator<Order> iterator = orderBook.iterator();
			StringBuilder sb = new StringBuilder();

			while (iterator.hasNext()) {
				Order order = iterator.next();
				sb.append(order);
				if (orderExecutions.size() > 0) {
					OrderExecution execution = orderExecutions.get(order.getOrderId());
					sb.append(execution);
				}
				orderStatistics.add(sb.toString());
			}
		}
		return null;
	}

	public List<String> getAllBooks() {

		List<String> books = orderBooks.entrySet().stream()
							.map(e1 -> e1.getValue().getInstrumentId() + "|" + e1.getValue().getIsOpen() + "|" + e1.getValue().getIsExecuted())
							.collect(Collectors.toList());

		return books;
	}

	@Override
	public List<String> getValidDemand() {

		List<String> validDemands = new LinkedList<String>();

		for (Map.Entry<String, OrderBook> book : orderBooks.entrySet()) {
			LinkedList<Order> orderBook = orders.get(book.getKey());
			Integer sumOfOrders = orderBook.stream()
									.filter(e1 -> (book.getValue().getIsExecuted() == null || book.getValue().getIsExecuted() == false)
											|| e1.getOrderType() == OrderType.MARKET
											|| (book.getValue().getExecutionPrice() != null
											&& e1.getLimitPrice() >= book.getValue().getExecutionPrice()))
									.mapToInt(e1 -> e1.getQuantity()).sum();
			validDemands.add(book.getKey() + " | " + sumOfOrders.toString());
		}

		return validDemands;
	}

	@Override
	public List<String> getInvalidDemand() {
		List<String> invalidDemand = new LinkedList<String>();

		for (Map.Entry<String, OrderBook> book : orderBooks.entrySet()) {

			if (book.getValue().getIsExecuted()) {

				LinkedList<Order> orderBook = orders.get(book.getKey());
				Integer sumOfOrders = orderBook.stream()
						.filter(e1 -> e1.getOrderType() == OrderType.LIMIT
								&& e1.getLimitPrice() < book.getValue().getExecutionPrice())
						.mapToInt(e1 -> e1.getQuantity()).sum();
				invalidDemand.add(book.getKey() + " | " + sumOfOrders.toString());
			}
		}
		return invalidDemand;
	}

	private void isValidInstrumentId(String instrumentId) throws InvalidInstrumenFormatException {
		if (!validInstruments.contains(instrumentId)) {
			throw new InvalidInstrumenFormatException(instrumentId);
		}
	}

	private void validateInstrument(String instrumentId) throws InvalidInstrumenFormatException {
		if (instrumentId.equals(null) || instrumentId.equals("")) {
			throw new InvalidInstrumenFormatException(instrumentId);
		}
	}

	private void validateQuantity(Integer quantity) throws InvalidQuantityException {
		if (quantity <= 0) {
			throw new InvalidQuantityException(quantity);
		}
	}

	private void validatePrice(Double price) throws InvalidPriceException {
		if (price <= 0) {
			throw new InvalidPriceException(price);
		}
	}
}
