package com.csgrp.oms.common;

/**
 * 
 * Custom exception class for invalid input
 * 
 * @author Ashish
 * @version 1.0
 * @since 1-12-2019
 */

public class InvalidQuantityException extends Exception {

	private Integer quantity;

	public InvalidQuantityException(Integer quantity) {
		this.quantity = quantity;
	}

	public Integer getAmount() {
		return quantity;
	}
}
