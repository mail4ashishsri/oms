package com.csgrp.oms.common;

/**
 * 
 * Custom exception class for invalid input
 * 
 * @author Ashish
 * @version 1.0
 * @since 1-12-2019
 */

public class InvalidInstrumenIdException extends Exception {

	private String id;

	public InvalidInstrumenIdException(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}
}
