package com.csgrp.oms;

import java.util.List;

import com.csgrp.oms.common.InvalidInstrumenFormatException;
import com.csgrp.oms.common.InvalidPriceException;
import com.csgrp.oms.common.InvalidQuantityException;

/*
 * It defines the contract for  order management service
 * 
 * @author	Ashish
 * @version	1.0
 * @since	1-12-2019
 */

public interface OrderManagement {
	
	/**
     * If provided instrument order book is 
     * not open, it will open new order book. 
     * 
     * <p>Null instrumentid value is not allowed.
     *
     * @param instrumentid is id of instrument to open new book  
     *      
     * @return boolean status of book creation
	 * @throws InvalidInstrumentException 
     */
	public boolean openOrderBook(String instrumentId) throws InvalidInstrumenFormatException;
		
	/**
     * If provided instrument book is in open 
     * state, it will close order book. 
     * 
     * <p>Null instrumentid value is not allowed.
     *
     * @param instrumentid is unique id of instrument to close book  
     *      
     * @return boolean status of book close action 
	 * @throws InvalidInstrumentException 
     */
	public boolean closeOrderBook(String instrumentId) throws InvalidInstrumenFormatException;
	
	/**
     * Book the order for provided instrument 
     *       
     * <p>Null instrumentid is quantity is not allowed.
     *       
     * @param instrumentid, quantity and price to book order  
     *      
     * @return boolean status of book close action 
	 * @throws InvalidInstrumentException 
	 * @throws InvalidQuantityException 
     */
	public boolean bookOrder(String instrumentId,Integer quantity, Double price) throws InvalidInstrumenFormatException, InvalidQuantityException;

	/**
     * Execute order book of provided instrument
     *       
     * <p>Null instrumentid, quantify and executionPrice are not allowed.
     *       
     * @param instrumentid, quantity and price to book order  
     *      
     * @return boolean status of book close action 
	 * @throws InvalidInstrumentException 
	 * @throws InvalidQuantityException 
	 * @throws InvalidQuantityException 
     */
	public String executeBook(String instrumentId, Integer quantity, Double executionPrice) throws InvalidInstrumenFormatException, InvalidQuantityException, InvalidQuantityException, InvalidPriceException;
	
	
	/**
     * Return order statistics
     */
	public List<String> getOrderStatistics();
	
	/**
     * Get total booking amount of each order book
     */
	public List<String> getSumOfEachBook();
	
	/**
     * Clear everything for maintence purpose
     */
	public void clearAllBooks();
	
	/**
     * Get list of books
     */
	public List<String> getAllBooks();
	
	/**
     * Get valid demands
     */
	public List<String> getValidDemand();
	
	/**
     * Get invalid demands
     */
	public List<String> getInvalidDemand();
	
}
