package com.csgrp.oms.common;

/**
 * 
 * Custom exception class for invalid input
 * 
 * @author Ashish 
 * @version 1.0
 * @since 1-12-2019
 */

public class InvalidPriceException  extends Exception{

	private Double price;

	public InvalidPriceException(Double price) {
		this.price = price;
	}

	public Double getAmount() {
		return price;
	}
}
