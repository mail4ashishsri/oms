package com.csgrp.oms.common;

public enum OrderType {
	MARKET, 
	LIMIT
}
